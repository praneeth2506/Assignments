/**
* @file prob2.c
* @brief this file has resizable deque
*
* @author Kurapati Praneeth
*
* @date 30/07/2019
*/
#include<stdio.h>
#include<stdlib.h>
int size=8;
int l=3,r=4,i;
int c=0; //count
void insl();
void insr();
void dell();
void delr();
void mover();
void movel();
void re();//doubling
void de();//half
void print();
int main(){
int *a=(int *)calloc(size,sizeof(int));
insl(1,a);
insl(2,a);
insl(3,a);
insl(4,a);
insl(5,a);
print();
insl(6,a);
insl(7,a);
insl(8,a);
insl(9,a);
print();
dell(a);
delr(a);
print();
printf("%d %d %d %d %d %d %d",a[0],a[1],a[2],a[3],a[4],a[5],a[6]);
}
/**
* This method will be used to insert a integer at left end of deque.
* @author K.Praneeth
* @param Data The integer to store
* @date 30/07/2019
*/
void insl(int k,int a[]){
    if(c!=size&&l==-1){
        mover(a);
        l++;
        r++;
    }
    if(c==size){
        re(a);
    }
    a[l]=k;
    printf("%d is inserted\n",k);
l--;
c++;
}
/**
* This method will be used to insert a integer at right end of deque.
* @author K.Praneeth
* @param Data The integer to store
* @date 30/07/2019
*/
void insr(int k,int a[]){
    if(c!=size&&r==size){
        movel(a);
        l--;
        r--;
    }
    if(c==size){
        re(a);
    }
   a[r]=k;
   printf("%d is inserted\n",k);
r++; 
c++;
}
void mover(int a[]){
	
  for( i=0;i<c;i++){
    a[r-i]=a[r-i-1];  
  }  
}
void movel(int a[]){
  for( i=0;i<c;i++){
    a[l+i]=a[l+i+1];  
  }  
}

void re(int a[]){
    size=2*size;
    a=(int *)realloc(a,size*sizeof(int));
    for( i=0;i<c;i++){
    a[(3*size/4)-i-1]=a[r-i-1];  
  } 
  r=3*size/4;
  l=size/4-1;
  printf("size is doubled\n");
}
/**
* This method will be used to remove a integer at left end of deque.
* @author K.Praneeth
* @param Data The integer to remove
* @date 30/07/2019
*/
void dell(int a[]){
	if(c==0)
	printf("deque is empty\n");
   else{
   l++;
    c--;
printf("%d is deleted\n",a[l]);
if(c<=size/2){
    de(a);
    }}
}
/**
* This method will be used to remove a integer at right end of deque.
* @author K.Praneeth
* @param Data The integer to remove
* @date 30/07/2019
*/
void delr(int a[]){\
if(c==0)
	printf("deque is empty\n");
  else{
  r--;
    c--;
printf("%d is deleted \n",a[r]);
if(c<=size/2){
    de(a);
    }}
}
void de(int a[]){
  for( i=0;i<c;i++){
      a[i]=a[l+1+i];
  }
  size=size/2;
    a=(int *)realloc(a,size*sizeof(int));
    l=-1;
    r=c;
    printf("size is halved\n");
}
/**
* This method will be used to print size of deque.
* @author K.Praneeth
* @param Data to print
* @date 30/07/2019
*/
void print(){
	printf("Current size is %d bytes \n",size*4);
}


