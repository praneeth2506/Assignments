/**
* @file prob1.c
* @brief this file doubly linked list
*
* @author Kurapati Praneeth
*
* @date 30/07/2019
*/

#include<stdio.h> 
#include<errno.h>


void insert();  
void del();  
void modify();  
void sort(); 
void swap(); 
void print();  
void search();
void get();
void qinsert();
int pop();

struct node  
{  
    struct node *prev;  
    struct node *next;  
    int rno;
    char name[50];
    char dob[20];
    char add[100];
    int phno;
    int flag;
};

struct node *head;  


int c=0; 
int unusedRollNo[13];
int front = 0;
int rear = -1;
int itemCount = 0;
char dd[1064];

/**
* This method will be used to insert a integer into queue named unusedRollno.
* @author K.Praneeth
* @param Data The integer to store
* @date 30/07/2019
*/

void qinsert(int data){
   if(!(itemCount == 13)) {
	
      if(rear == 12) {
         rear = -1;            
      }       

      unusedRollNo[++rear] = data;
      itemCount++;
   }
}

/**
* This method will be used to pop a integer from queue.
* @author K.Praneeth
* @param Data The integer to remove
* @date 30/07/2019
*/
int pop(){
  int data = unusedRollNo[front++];
	
   if(front == 13) {
      front = 0;
   }
	
   itemCount--;
   return data;   
}
/**
* This method will be used to create a node insert data about student into linked list.
* @author K.Praneeth
* @param Data to store
* @date 30/07/2019
*/
void insert(int s){
    struct node *ptr,*temp;  
   int r;  
   
   if(itemCount != 0)  
   {  
       int k=pop()-101;
       temp=head;
       while(k-->0){
       	temp=temp->next;
	   }
	     get(temp,s);
   }  
   else  
   {  ptr = (struct node *) malloc(sizeof(struct node));  
        
        ptr->rno=101+c;  
       if(head == NULL)  
       {  
           head = ptr;  
           ptr -> next = head;   
           ptr -> prev = head;
           get(ptr,s);
       }  
       else  
       {  
          temp = head;  
          while(temp->next !=head)  
          {  
              temp = temp->next;  
          }  
          temp->next = ptr;  
          ptr ->prev=temp;  
          head -> prev = ptr;  
      ptr -> next = head;  
        } 
		c++; 
		get(ptr,s);
   }  
     
}

void get(struct node *a,int s){
	
	FILE* fp=fopen("C:\\Users\\DELL\\Documents\\StudentData.csv","r");
	if (fp==NULL) 
    { 	
        printf(" red file is not loaded"); 
        return 0;
    } 
	s++;
	while(s-->0){
		fgets(dd,1064,fp);
	}
	
	char* token = strtok(dd, ","); 
	token = strtok(NULL, ","); 
	  strcpy(a->name,token);
	  token = strtok(NULL, ",");
	   strcpy(a->dob,token);
	  token = strtok(NULL, "\"");
	  strcpy(a->add,token); 
	  token = strtok(NULL, ",");
	   a->phno=atoi(token);
	   	a->flag=1;
	   	rewind(fp);
}
/**
* This method will be used to remove info of student.
* @author K.Praneeth
* @param Data to remove
* @date 30/07/2019
*/

void del(int r){
	if(r>100+c)
	printf(" %d rollno is not yet defined\n",r);
	else{
	int g=r-101;
	struct node *temp;
	temp=head;
	while(g-->0){
		temp=temp->next;
	}
	temp->flag=0;
	printf("%d %s %s %s %d is deleted \n",temp->rno,temp->name,temp->dob,temp->add,temp->phno);
	qinsert(r);}
}
/**
* This method will be used to print informations in linked list.
* @author K.Praneeth
* @param 
* @date 30/07/2019
*/
void print(){
struct node *node;
node=head;
if(node->flag==1)
printf("%d %s %s %s %d \n",node->rno,node->name,node->dob,node->add,node->phno);
node=node->next;
while(node!=head){
if(node->flag==1)
printf("%d %s %s %s %d \n",node->rno,node->name,node->dob,node->add,node->phno);
node=node->next;	
}	
}
/**
* This method will be used tomodify data in node.
* @author K.Praneeth
* @param Data  to modify
* @date 30/07/2019
*/

void modify(int r){
int g=r-101;
	struct node *temp;
	temp=head;
	while(r>0){
	if(temp->rno==r)
	break;	
		temp=temp->next;}
	printf("print new data");
	scanf("%s %s %s %d",&temp->name,&temp->dob,&temp->add,&temp->phno);
}

void swap(struct node *a,struct node *b){ 
	struct node *temp=(struct node *)malloc(sizeof(struct node));
	temp->rno=a->rno;
	a->rno=b->rno;
	b->rno=temp->rno;
	strcpy(temp->dob,a->dob);
	strcpy(a->dob,b->dob);
	strcpy(b->dob,temp->dob);
	strcpy(temp->name,a->name);
	strcpy(a->name,b->name);
	strcpy(b->name,temp->name);
	strcpy(temp->add,a->add);
	strcpy(a->add,b->add);
	strcpy(b->add,temp->add);
	temp->phno=a->phno;
	a->phno=b->phno;
	b->phno=temp->phno; 
}
/**
* This method will be used to sort all nodes in order.
* @author K.Praneeth
* @param linked list sorting
* @date 30/07/2019
*/
void sort(struct node *node){
		printf("sorting is done\n");
	struct node *i,*j;
	int x,k,l;
	for(i=node,k=0;k<c;i=i->next,k++){
		for(j=node,l=0;l<c;j=j->next,l++){
			if(i->flag==1&&j->flag==1){
			x=strcmp(i->name,j->name); 
			if(x<0) swap(i,j); 
		}
	}
	
}
}
int main()
{
    insert(1);
    insert(2);
	insert(3);
	print();
	del(104);
print();
	sort(head);
	print();
    return 0;
}



