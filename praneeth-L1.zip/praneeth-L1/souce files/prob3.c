/**
* @file prob3.c
* @brief this file has specific operations on image
*
* @author Kurapati Praneeth
*
* @date 30/07/2019
*/
#include <stdio.h>
char ch1,ch2,ch3,ch4;
void rered();
void regreen();
void reblue();
void redo();
void gro();
void blo();
void pixelValue();
int main()
{
    FILE* fr = fopen("Q3_ip_Red.dat","r"); 
    FILE* fb = fopen("Q3_ip_Blue.dat","r"); 
    FILE* fg = fopen("Q3_ip_Green.dat","r");
    
    if (fr==NULL) 
    { 
        printf(" red file is not loaded"); 
        return 0;
    } 
    if (fb==NULL) 
    { 
        printf("blue file is not loaded"); 
        return 0; 
    } 
    if (fg==NULL) 
    { 
        printf(" green file is not loaded"); 
        return 0; 
    } 

pixelValue(fr,fg,fb,1,0);
    return 0;
}
/**
* This method will be used to return the pixel values r,g,b at specified point.
* @author K.Praneeth
* @param Data The pixel values are returned
* @date 30/07/2019
*/
void pixelValue(FILE*fr,FILE*fg,FILE*fb,int x,int y){
	char dd[1064];
	int dr,dg,db;
    char ch1,ch2,ch3;
	x++;
	while(y-->0){
		fgets(dd,1064,fr);
    fgets(dd,1064,fg);
	fgets(dd,1064,fb); 
	}
	while(x-->0){
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);	
	}
	printf("Red pixel value is %d\n Green pixel value is %d \n Blue pixel value is %d",dr,dg,db);
	
} 

/**
* This method will be used to remove red shades.
* @author K.Praneeth
* @param new file is created
* @date 30/07/2019
*/
void rered(FILE*fr,FILE*fg,FILE*fb){
    int dr,dg,db;
    char ch1,ch2,ch3;
  FILE* nr = fopen("Q3_op_Red.dat","w"); 
    FILE* nb = fopen("Q3_op_Blue.dat","w"); 
    FILE* ng = fopen("Q3_op_Green.dat","w");
    fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);
	
    while(dg!=EOF)
	{
	
	
	if(db<dr&&dg<dr)
	{dr = 0;}
	
  fprintf(nb,"%d%c ",db,ch1);
	 fprintf(ng,"%d%c ",dg,ch2);
 	 fprintf(nr,"%d%c ",dr,ch3);
	
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);}
printf("red shades are removed");	
}

/**
* This method will be used to remove green shades.
* @author K.Praneeth
* @param new file is created
* @date 30/07/2019
*/
void regreen(FILE*fr,FILE*fg,FILE*fb){
int dr,dg,db;
    char ch1,ch2,ch3;
  FILE* nr = fopen("Q3_op_Red.dat","w"); 
    FILE* nb = fopen("Q3_op_Blue.dat","w"); 
    FILE* ng = fopen("Q3_op_Green.dat","w");
    fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);
	
    while(dg!=EOF)
	{
	
	
	if(db<dg&&dg>dr)
	{dg = 0;}
	
  fprintf(nb,"%d%c ",db,ch1);
	 fprintf(ng,"%d%c ",dg,ch2);
 	 fprintf(nr,"%d%c ",dr,ch3);
	
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);}	
	printf("green shades are removed");
}

/**
* This method will be used to remove blue shades.
* @author K.Praneeth
* @param new file is created
* @date 30/07/2019
*/
void reblue(FILE*fr,FILE*fg,FILE*fb){
	int dr,dg,db;
    char ch1,ch2,ch3;
  FILE* nr = fopen("Q3_op_Red.dat","w"); 
    FILE* nb = fopen("Q3_op_Blue.dat","w"); 
    FILE* ng = fopen("Q3_op_Green.dat","w");
    fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);
	
    while(dg!=EOF)
	{
	
	
	if(db>dg&&db>dr)
	{db = 0;}
	
  fprintf(nb,"%d%c ",db,ch1);
	 fprintf(ng,"%d%c ",dg,ch2);
 	 fprintf(nr,"%d%c ",dr,ch3);
	
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);}
	printf("blue shades are removed");
}

/**
* This method will be used to remove blue and green shades.
* @author K.Praneeth
* @param new file is created
* @date 30/07/2019
*/
void redo(FILE*fr,FILE*fg,FILE*fb){
int dr,dg,db;
    char ch1,ch2,ch3;
  FILE* nr = fopen("Q3_op_Red.dat","w"); 
    FILE* nb = fopen("Q3_op_Blue.dat","w"); 
    FILE* ng = fopen("Q3_op_Green.dat","w");
    fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);
	
    while(dg!=EOF)
	{
	
	
	if(db>dg&&db>dr)
	{db = 0;}
	if(db<dg&&dg>dr)
	{dg = 0;}
	
  fprintf(nb,"%d%c ",db,ch1);
	 fprintf(ng,"%d%c ",dg,ch2);
 	 fprintf(nr,"%d%c ",dr,ch3);
	
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);}	
	printf("only red shades are left");
}

/**
* This method will be used to remove red and blue shades.
* @author K.Praneeth
* @param new file is created
* @date 30/07/2019
*/
void gro(FILE*fr,FILE*fg,FILE*fb){
	int dr,dg,db;
    char ch1,ch2,ch3;
  FILE* nr = fopen("Q3_op_Red.dat","w"); 
    FILE* nb = fopen("Q3_op_Blue.dat","w"); 
    FILE* ng = fopen("Q3_op_Green.dat","w");
    fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);
	
    while(dg!=EOF)
	{
	if(db<dr&&dg<dr)
	{dr = 0;}
	
	if(db>dg&&db>dr)
	{db = 0;}
	
  fprintf(nb,"%d%c ",db,ch1);
	 fprintf(ng,"%d%c ",dg,ch2);
 	 fprintf(nr,"%d%c ",dr,ch3);
	
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);}
	printf("only green shades are left");
}
/**
* This method will be used to remove red and green shades.
* @author K.Praneeth
* @param new file is created
* @date 30/07/2019
*/
void blo(FILE*fr,FILE*fg,FILE*fb){
int dr,dg,db;
    char ch1,ch2,ch3;
  FILE* nr = fopen("Q3_op_Red.dat","w"); 
    FILE* nb = fopen("Q3_op_Blue.dat","w"); 
    FILE* ng = fopen("Q3_op_Green.dat","w");
    fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);
	
    while(dg!=EOF)
	{
	if(db<dr&&dg<dr)
	{dr = 0;}
	
	if(db<dg&&dg>dr)
	{dg = 0;}
	
  fprintf(nb,"%d%c ",db,ch1);
	 fprintf(ng,"%d%c ",dg,ch2);
 	 fprintf(nr,"%d%c ",dr,ch3);
	
	fscanf(fr,"%d%c", &dr, &ch1);
	fscanf(fb,"%d%c", &db, &ch2);
	fscanf(fg,"%d%c", &dg, &ch3);}
	printf("only blue shades are left");	
}
