var searchData=
[
  ['pixelvalue',['pixelValue',['../prob3_8c.html#a6e2aaed363272bb5b8315f955ebd5886',1,'prob3.c']]]
];
