var searchData=
[
  ['reblue',['reblue',['../prob3_8c.html#ad616749519b5805c374e292dd8dd2429',1,'prob3.c']]],
  ['redo',['redo',['../prob3_8c.html#adfa3329324b812d49d47b10b83146344',1,'prob3.c']]],
  ['regreen',['regreen',['../prob3_8c.html#ab6a62d84d6aba60bd4760677c9b0026c',1,'prob3.c']]],
  ['rered',['rered',['../prob3_8c.html#af5da42762b7c09e5d3f7d5e4bc1f42e4',1,'prob3.c']]]
];
