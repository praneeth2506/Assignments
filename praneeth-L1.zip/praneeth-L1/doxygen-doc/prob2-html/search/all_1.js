var searchData=
[
  ['insl',['insl',['../prob2_8c.html#a666b503b15a648eea0fbd267ae2cb84c',1,'prob2.c']]],
  ['insr',['insr',['../prob2_8c.html#a83565c22f38174b6b74bbccce0a7f84d',1,'prob2.c']]]
];
