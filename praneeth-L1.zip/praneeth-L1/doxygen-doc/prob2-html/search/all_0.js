var searchData=
[
  ['dell',['dell',['../prob2_8c.html#a923522adb1494bf71350158c2f98c3c9',1,'prob2.c']]],
  ['delr',['delr',['../prob2_8c.html#a62d22a2489050af169f055f958c919c6',1,'prob2.c']]]
];
