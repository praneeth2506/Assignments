var searchData=
[
  ['insert',['insert',['../prob1_8c.html#acf38e49fa1629a277933f2bba2b1257e',1,'prob1.c']]]
];
