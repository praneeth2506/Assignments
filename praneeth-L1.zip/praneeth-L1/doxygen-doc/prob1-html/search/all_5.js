var searchData=
[
  ['qinsert',['qinsert',['../prob1_8c.html#abb010620e8b844d366dddcdb2966c122',1,'prob1.c']]]
];
