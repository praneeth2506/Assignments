#include <bits/stdc++.h> 
#include <iostream>
using std::cerr;
using std::endl;
#include <fstream>
using std::ofstream;
#include <cstdlib>
using namespace std; 
class Edge 
{ 
	public: 
	int str, end, wt; 
};
class Graph 
{ 
	public: 
	int V,E;
	Edge* edge; 
}; 
Graph* cGraph(int V, int E) 
{ 
	Graph* graph = new Graph; 
	graph->V = V; 
	graph->E = E; 

	graph->edge = new Edge[E]; 

	return graph; 
} 
class subset 
{ 
	public: 
	int parent; 
	int rank; 
}; 
int find(subset subsets[], int i) 
{  
	if (subsets[i].parent != i) 
		subsets[i].parent = find(subsets, subsets[i].parent); 

	return subsets[i].parent; 
}
void Union(subset subsets[], int x, int y) 
{ 
	int xroot = find(subsets, x); 
	int yroot = find(subsets, y);  
	if (subsets[xroot].rank < subsets[yroot].rank) 
		subsets[xroot].parent = yroot; 
	else if (subsets[xroot].rank > subsets[yroot].rank) 
		subsets[yroot].parent = xroot; 
	else
	{ 
		subsets[yroot].parent = xroot; 
		subsets[xroot].rank++; 
	} 
} 
 
int myComp(const void* a, const void* b) 
{ 
	Edge* a1 = (Edge*)a; 
	Edge* b1 = (Edge*)b; 
	return a1->wt > b1->wt; 
} 
void Kruskal(Graph* graph) 
{ 
	int V = graph->V; 
	Edge result[V]; 
	int e=0;int i=0;
	qsort(graph->edge, graph->E, sizeof(graph->edge[0]), myComp); 
	
     subset *subsets = new subset[( V * sizeof(subset) )];  
	for (int v = 0; v < V; ++v) 
	{ 
		subsets[v].parent = v; 
		subsets[v].rank = 0; 
	}
	while (e < V - 1 && i < graph->E) 
	{ 
	Edge next_edge = graph->edge[i++]; 

		int x = find(subsets, next_edge.str); 
		int y = find(subsets, next_edge.end); 

		if (x != y) 
		{ 
			result[e++] = next_edge; 
			Union(subsets, x, y); 
		} 
		
	} 
	FILE *fp1=fopen("graph.dot","w");
 ofstream outdata;
    outdata.open("graph.dot"); // opens the file
   if( !outdata ) { // file couldn't be opened
      cerr << "Error: file could not be opened" << endl;
      exit(1);
   }
    cout<<"Following are the edges in the constructed MST\n"; 
    for (i = 0; i < e; ++i) {
        cout<<(char)(result[i].str+65)<<" "<<(char)(result[i].end+65)<<" "<<result[i].wt<<endl; 
        outdata<<(char)(result[i].str+65)<<"--"<<(char)(result[i].end+65)<<"[label=\""<<result[i].wt<<"\"]"<<endl; 
    }
    outdata.close();
    return; 
} 

int main() 
{  
    int s=0,count=0,i; 
    Graph* graph = cGraph(100, 100); 
    FILE *fp=fopen("2019_CSN_261_L5_P2.csv","r");
    if(fp==NULL){
    	printf("File not loaded");
    	return 0;
	}
    char ch;
    int c1[100],c2[100];
    int a[100],store[100];
    while(EOF!=fscanf(fp,"%c",&ch)){ s--; 
        if(ch=='\n') s=1;
      if(ch==',') count++;
      if(ch!=','&&ch!='\n'&&(int)ch>45){ 
      if(count%2==0){
    if(s>=0||count==0) {c1[count/2]=(int)ch-65;  }
        else{ if((int)ch!=13) a[count/2-1]=(int)ch; if(a[count/2-1]>13) a[count/2-1]-=48;  }
      }
      else{
         c2[(count-1)/2]=(int)ch-65;
      }
  }
    }
    
    for(i=0;i<count/2;i++){
    graph->edge[i].str = c1[i]; 
    graph->edge[i].end = c2[i]; 
    graph->edge[i].wt = a[i];
    }

    Kruskal(graph); 

    return 0; 
} 
