#include <iostream>
#include <map> 
using namespace std;
int main(){
	int n1,n2,i,k,l;
	map<int, int> p1,p2,mul;
	printf("No. of terms in the expression:");
	cin>>n1;
	printf("Coefficient Power ");
	for(i=1;i<=n1;i++)
	{cin>>k;cin>>l;
	p1.insert(pair<int, int>(l, k)); 	
	}
    printf("No. of terms in the expression:");
	cin>>n2;
	printf("Coefficient Power ");
	for(i=1;i<=n2;i++)
	{cin>>k;cin>>l;
	p2.insert(pair<int, int>(l, k)); 	
	}  
	printf("Enter 1 to add or 2 for multiply ");
	cin>>k;
	l=max(n1,n2);
	if(k==1){
		for(int i=l-1;i>=0;i--)
		printf("%d  %d\n",p1[i]+p2[i],i);
		//add[i]=p1[i]+p2[i];
	}
	if(k==2){
		int n=n1+n2-2;
		for(int i=0;i<=n;i++)
		mul.insert(pair<int, int>(i, 0));
		map<int, int>::iterator j,o;
		for (j = p1.begin(); j!= p1.end(); ++j){
		//mul.insert(pair<int, int>(l, k));
		 for (o = p2.begin(); o!= p2.end(); ++o){
		 	mul[j->first+o->first]+=j->second*o->second;
		 }	
		}
		for(int i=n;i>=0;i--)
		printf("%d  %d\n",mul[i],i);
	}
	return 0;
}
