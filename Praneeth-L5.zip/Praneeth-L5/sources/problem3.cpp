#include <bits/stdc++.h> 
using namespace std; 

struct AdjListNode { 
	int end; 
	int wt; 
	struct AdjListNode* next; 
}; 
 
struct AdjList { 
	struct AdjListNode* head; 
}; 
 
struct Graph { 
	int V; 
	struct AdjList* array; 
}; 

struct AdjListNode* newAdjListNode(int end, int wt) 
{ 
	struct AdjListNode* newNode = (struct AdjListNode*)malloc(sizeof(struct AdjListNode)); 
	newNode->end = end; 
	newNode->wt = wt; 
	newNode->next = NULL; 
	return newNode; 
} 

struct Graph* cGraph(int V) 
{ 
	struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph)); 
	graph->V = V; 
	graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList));  
	for (int i = 0; i < V; ++i) 
		graph->array[i].head = NULL; 

	return graph; 
} 
 
void addEdge(struct Graph* graph, int str, int end, int wt) 
{ 
	struct AdjListNode* newNode = newAdjListNode(end, wt); 
	newNode->next = graph->array[str].head; 
	graph->array[str].head = newNode; 

	newNode = newAdjListNode(str, wt); 
	newNode->next = graph->array[end].head; 
	graph->array[end].head = newNode; 
} 
 
struct FibonaciheapNode { 
	int v; 
	int key; 
}; 

struct Fibonaciheap { 
	int size;  
	int capacity; 
	int* pos; 
	struct FibonaciheapNode** array; 
}; 
 
struct FibonaciheapNode* newFibonaciheapNode(int v, int key) 
{ 
	struct FibonaciheapNode* fibheapNode = (struct FibonaciheapNode*)malloc(sizeof(struct FibonaciheapNode)); 
	fibheapNode->v = v; 
	fibheapNode->key = key; 
	return fibheapNode; 
} 

struct Fibonaciheap* createFibonaciheap(int capacity) 
{ 
	struct Fibonaciheap* fibheap = (struct Fibonaciheap*)malloc(sizeof(struct Fibonaciheap)); 
	fibheap->pos = (int*)malloc(capacity * sizeof(int)); 
	fibheap->size = 0; 
	fibheap->capacity = capacity; 
	fibheap->array = (struct FibonaciheapNode**)malloc(capacity * sizeof(struct FibonaciheapNode*)); 
	return fibheap; 
} 
 
void SwapNode(struct FibonaciheapNode** a, struct FibonaciheapNode** b) 
{ 
	struct FibonaciheapNode* t = *a; 
	*a = *b; 
	*b = t; 
} 

void fibheapify(struct Fibonaciheap* fibheap, int idx) 
{ 
	int smallest, left, right; 
	smallest = idx; 
	left = 2 * idx + 1; 
	right = 2 * idx + 2; 

	if (left < fibheap->size && fibheap->array[left]->key < fibheap->array[smallest]->key) 
		smallest = left; 

	if (right < fibheap->size && fibheap->array[right]->key < fibheap->array[smallest]->key) 
		smallest = right; 

	if (smallest != idx) { 
		FibonaciheapNode* smallestNode = fibheap->array[smallest]; 
		FibonaciheapNode* idxNode = fibheap->array[idx]; 
		fibheap->pos[smallestNode->v] = idx; 
		fibheap->pos[idxNode->v] = smallest; 
		SwapNode(&fibheap->array[smallest], &fibheap->array[idx]); 

		fibheapify(fibheap, smallest); 
	} 
}  
int isEmpty(struct Fibonaciheap* fibheap) 
{ 
	return fibheap->size == 0; 
}
struct FibonaciheapNode* extractMin(struct Fibonaciheap* fibheap) 
{ 
	if (isEmpty(fibheap)) 
		return NULL;  
	struct FibonaciheapNode* root = fibheap->array[0]; 
	struct FibonaciheapNode* lastNode = fibheap->array[fibheap->size - 1]; 
	fibheap->array[0] = lastNode; 
fibheap->pos[root->v] = fibheap->size - 1; 
	fibheap->pos[lastNode->v] = 0; 
--fibheap->size; 
	fibheapify(fibheap, 0); 

	return root; 
} 
 
void decreaseKey(struct Fibonaciheap* fibheap, int v, int key) 
{ 
	int i = fibheap->pos[v]; 
fibheap->array[i]->key = key; 

	while (i && fibheap->array[i]->key < fibheap->array[(i - 1) / 2]->key) { 
	 
		fibheap->pos[fibheap->array[i]->v] = (i - 1) / 2; 
		fibheap->pos[fibheap->array[(i - 1) / 2]->v] = i; 
		SwapNode(&fibheap->array[i], &fibheap->array[(i - 1) / 2]); 

		i = (i - 1) / 2; 
	} 
} 

bool isInFibonaciheap(struct Fibonaciheap* fibheap, int v) 
{ 
	if (fibheap->pos[v] < fibheap->size) 
		return false; 
	return true; 
} 
 
void printArr(int arr[],int b[], int n) 
{ 
	for (int i = 1; i < n; ++i) 
		printf("%c- %c - %d\n", (char)(arr[i]+65),(char)(i+65),b[i]); 
} 

void PrimMST(struct Graph* graph) 
{ 
	int V = graph->V; 
	int super[V]; 
	int key[V]; 

	struct Fibonaciheap* fibheap = createFibonaciheap(V); 

	for (int v = 1; v < V; ++v) { 
		super[v] = -1; 
		key[v] = INT_MAX; 
		fibheap->array[v] = newFibonaciheapNode(v, key[v]); 
		fibheap->pos[v] = v; 
	} 

	key[0] = 0; 
	fibheap->array[0] = newFibonaciheapNode(0, key[0]); 
	fibheap->pos[0] = 0; 

	fibheap->size = V; 

	while (!isEmpty(fibheap)) { 

		struct FibonaciheapNode* fibheapNode = extractMin(fibheap); 
		int u = fibheapNode->v; 

		struct AdjListNode* pCrawl = graph->array[u].head; 
		while (pCrawl != NULL) { 
			int v = pCrawl->end; 

			if (!isInFibonaciheap(fibheap, v) && pCrawl->wt < key[v]) { 
				key[v] = pCrawl->wt; 
				super[v] = u; 
                //cout<<key[v];
				decreaseKey(fibheap, v, key[v]); 
			} 
			pCrawl = pCrawl->next; 
		} 
	} 

	printArr(super,key, V); 
} 

int main() 
{ 	
    string a,b,c;
	int i=0,count=0,c2=0;
    int edge=0,vert=0;
	i=0;
	int j=0;
    int arr[100];
    for(j=0;j<100;j++)
        arr[j]=0;

    ifstream ip3("2019_CSN_261_L5_P2.csv");
    while(ip3.good()){
        getline(ip3,a,',');
        getline(ip3,b,',');
        getline(ip3,c,'\n');

		for(j=0;j<vert;j++){
            if(a[0]==arr[j])
                break;
        }
        if(j==vert){
            arr[j]=a[0];
            vert=vert+1;
        }

        for(j=0;j<vert;j++){
            if(b[0]==arr[j])
                break;
        }
        if(j==vert){
            arr[j]=b[0];
            vert++;
        }
    }
    cout<<vert<<endl;

	int V = 6; 

	struct Graph* graph = cGraph(V); 

	ifstream ip2("2019_CSN_261_L5_P2.csv");
    
    while(ip2.good()){
        getline(ip2,a,',');
        getline(ip2,b,',');
        getline(ip2,c,'\n');
		cout<<a[0]<<" "<<b[0]<<" "<<c[0]<<endl;
		addEdge(graph,a[0]-65,b[0]-65,c[0]-48); 

    }
	PrimMST(graph); 

	return 0; 
}
