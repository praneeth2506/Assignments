var indexSectionsWithContent =
{
  0: "dimnpqs",
  1: "n",
  2: "p",
  3: "dimpqs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions"
};

