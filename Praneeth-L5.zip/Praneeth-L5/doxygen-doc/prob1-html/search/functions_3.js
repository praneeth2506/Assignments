var searchData=
[
  ['pop',['pop',['../prob1_8c.html#a163177f1a0b7d847bc3241809dafc097',1,'prob1.c']]],
  ['print',['print',['../prob1_8c.html#a388f572c62279f839ee138a9afbdeeb5',1,'prob1.c']]]
];
