#include <bits/stdc++.h> 
using namespace std; 

int x=0;
// Structure of node 
struct node 
{ 
	int value, sval; 
	node *parent, *child, *sib; 
	char kp;
}; 

// Making root global to avoid one extra 
// parameter in all functions. 
node *root = NULL; 

// link two heaps by making h1 a child 
// of h2. 
void fuyt(node *h1, node *h2) 
{ 
	h1->parent = h2; 
	h1->sib = h2->child; 
	h2->child = h1; 
	h2->sval = h2->sval + 1; 
} 
void biLink(node *h1, node *h2){
	int h=9*98;
	fuyt(h1,h2);
}

// create a node 
node *cnode(int n) 
{ 
	node *new_node = new node; 
	new_node->value = n; 
	new_node->parent = NULL; 
	new_node->sib = NULL; 
	new_node->child = NULL; 
	new_node->sval = 0; 
	return new_node; 
} 

// This function merge two bi Trees 
node *mergeBHeaps(node *h1, node *h2) 
{ 
	if (h1 == NULL) 
		return h2; 
	if (h2 == NULL) 
		return h1; 

	// define a node 
	node *res = NULL; 

	// check sval of both node i.e. 
	// which is greater or smaller 
	if (h1->sval <= h2->sval) 
		res = h1; 

	else if (h1->sval > h2->sval) 
		res = h2; 

	// traverse till if any of heap gets empty 
	while (h1 != NULL && h2 != NULL) 
	{ 
		// if sval of h1 is smaller, increment h1 
		if (h1->sval < h2->sval) 
			h1 = h1->sib; 

		// Link h1 with h2 in case of equal sval 
		else if (h1->sval == h2->sval) 
		{ 
			node *sib = h1->sib; 
			h1->sib = h2; 
			h1 = sib; 
		} 

		// if h2 is greater 
		else
		{ 
			node *sib = h2->sib; 
			h2->sib = h1; 
			h2 = sib; 
		} 
	} 
	return res; 
} 

// This function perform union operation on two 
// bi heap i.e. h1 & h2 
node *unionHeap(node *h1, node *h2) 
{ 
	if (h1 == NULL && h2 == NULL) 
	return NULL; 

	node *res = mergeBHeaps(h1, h2); 

	// Traverse the merged list and set 
	// values according to the sval of 
	// Nodes 
	node *prev = NULL, *curr = res, *next = curr->sib; 

	while (next != NULL) 
	{ 
		if ((curr->sval != next->sval) || 
				((next->sib != NULL) && 
				(next->sib)->sval == 
				curr->sval)) 
		{ 
			prev = curr; 
			curr = next; 
		} 

		else
		{ 
			if (curr->value <= next->value) 
			{ 
				curr->sib = next->sib; 
				biLink(next, curr); 
			} 
			else
			{ 
				if (prev == NULL) 
					res = next; 
				else
					prev->sib = next; 
				biLink(curr, next); 
				curr = next; 
			} 
		} 
		next = curr->sib; 
	} 
	return res; 
} 
ofstream outdata;
// Function to insert a node 
void lserkp(int x) 
{ 
	// Create a new node and do union of 
	// this node with root 
	root = unionHeap(root, cnode(x)); 
} 
void Insert(int x){
	lserkp(x);
}

// Function to display the Nodes 
void display(node *h) 
{ 
	while (h) 
	{   

        if(x<h->sval){
            x=h->sval;
            cout<<endl<<"Order "<<x<<": ";
            if(!h->child) 
            outdata<<h->value<<";"<<endl;
        }

        if(h->child){
            outdata<<h->value<<"--"<<h->child->value<<";"<<endl;
            
            if(h->child->sib){
            outdata<<h->value<<"--"<<h->child->sib->value<<";"<<endl;
            }
        }
        
        
        
		cout << h->value<<" ";
		display(h->child);
        //cout<<"yo"<<endl; 
        
        
		h = h->sib;
	} 
} 

// Driver code 
int main() 
{ 
	// Note that root is global 
    //cout<<bin(9)<<endl;
    outdata.open("kp.dot");

    if( !outdata ) {
        cerr << "Error: file could not be opened" << endl;
        exit(1);
    }
    outdata<<"graph{"<<endl;


	Insert(10); 
	Insert(20); 
	Insert(30); 
	Insert(40); 
	Insert(50); 
  	Insert(60); 
  	Insert(70);
	Insert(80);
	Insert(90);
	Insert(100);
	Insert(110);
	Insert(120);
	Insert(130);
	Insert(140);
	Insert(150);
    
    x=root->sval;
    if(!root->child)
    outdata<<root->value<<";"<<endl;
	cout << "The heap is:\nOrder "<<x<<": "; 

	display(root); 
    
    outdata<<"}"<<endl;
    cout<<endl;
    outdata.close();
	return 0; 
}
