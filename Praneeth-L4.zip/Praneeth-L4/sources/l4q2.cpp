#include<bits/stdc++.h>
using namespace std;
int a[50][50];
int c=0;
int d=0;
/**
* returns whether check or not
*/
bool isSafe(int n,int row,int column)
{
   for(int i=row-1;i>=0;i--)
   {
       if(a[i][column]==1)
       return false;
   }
   for(int i=row-1,j=column-1;i>=0,j>=0;i--,j--)
   {
       if(a[i][j]==1)
       return false;
   }
   
   for(int i=row-1,j=column+1;i>=0,j<n;i--,j++)
   {
       if(a[i][j]==1)
       return false;
   }
   return true;
}
/**
* assigns queen ans checks
*/
void NQueensH(int n,int row)
{
    if(row==n)
    {c++;
        cout<<"Combination:"<<c<<endl;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(a[i][j]==1)
                cout<<"1\t";
                else
                cout<<"0\t";
            }
            cout<<endl;
        }
        cout<<endl;
        d=1;
        return;
    }
    for(int j=0;j<n;j++)
    {
        if(isSafe(n,row,j))
        {
           a[row][j]=1;
           NQueensH(n,row+1);
           a[row][j]=0;
        }
    }
    return;
}
/**
* starts NQueens
*/
void NQueens(int n)
{
    memset(a,0,50*50*sizeof(int));
    NQueensH(n,0);
}
/**
* main
*/
int main()
{
    int n;
    cout<<"Enter the value";
    cin>>n;
    NQueens(n);
    if(d==0)cout<<"not possible";
    else{
    cout<<"No of combinations are "<<c;	
	}
    return 0;
}
