#include <iostream>
#include <iterator>
#include <map>

using namespace std;
/**
*main 
*/
int main(){
//int n,i,sum=0,h=0,ans,low=0,high=0,f_low=0,f_high=0;
int n,i,k,l=0,r=0,r1=-1,l1=-1,s=0,h=0;
  map<int,int> ar;
    cout<<"Enter number of elements";
    cin>>n;
    int a[n];
    cout<<"Enter the elements";
    for(i=0;i<n;i++){
    cin>>a[i];
    ar.insert(pair<int, int>(i, a[i]));
    }
    cout<<"Enter n:";
    cin>>k;
    map<int, int>::iterator j;
    for (j = ar.begin(); j!= ar.end(); ++j) { 
	      s=0;
    for(i=j->first;i<n;i++){
         s=s+a[i]; 
		 if(r-l>h) h=r-l;
          if(s==k){
          	l=j->first;
              r=i;
              if(r-l>h)
			  {  h=r-l;
			   r1=r;
			   l1=l;
			  }
         }
    }
    }
    if(r1==-1&&l1==-1)
    cout<<"Not Found";
    else{
	
    cout<<"Length of longest sub array is "<<h+1<<endl;
    cout<<"Index is  from "<<l1<<" to "<<r1;}
}
