#include <bits/stdc++.h>
#include<iostream>
#include<stdlib.h>
using namespace std;
struct Node {
    bool isEnd;
    map<char,struct Node*> map;
    string meaning;
};
Node* getNewTrieNode()
{
    Node* node = new Node;
    node->isEnd = false;
    return node;
}
/**
* Inserts node
*/
void insertNode(Node*& root, const string& str,
            const string& meaning)
{
    if (root == NULL)
        root = getNewTrieNode();

    Node *temp = root;
    for (int i = 0; i < str.length(); i++) {
        char x = str[i];
        if (temp->map.find(x) == temp->map.end())
            temp->map[x] = getNewTrieNode();

        temp = temp->map[x];
    }
    temp->isEnd= true;
    temp->meaning = meaning;
}
/**
* Takes word and prints meaning
*/
string Meaning(Node* root, const string& word)
{
    if (root == NULL)
        return "Invaid word";

    Node* temp = root;
    for (int i = 0; i < word.length(); i++) {
        temp = temp->map[word[i]];
        if (temp == NULL)
            return "Invalid word";
    }
    if (temp->isEnd)
        return temp->meaning;
    return "Invalid word";
}
/**
* main
*/
int main()
{  char ch;
    int countl=0,i=0,j=0,quotes=0,k=0,l=0,y=0,count=0;
    Node* root = NULL;
    FILE *fp=fopen("L4_P1_input.csv","r");

    char ks[100][100];

    char ks1[100][100];


    if(fp==NULL) printf("FILE not loaded");
    while(EOF!=fscanf(fp,"%c",&ch)){ y=0;
    if(ch=='\n'){ y=1;  i++; k++; countl--; count++; }
if(ch=='\"'){ y=1; quotes++; if(quotes%2==0){  l=0; j=0; } }
    if(quotes%2==0) {if(ch==','){ y=1; countl++; j=0; l=0;  } }
    if(y==0){
    if(countl%2==0) { ks[i][j]=ch; j++; }
    else{ ks1[k][l]=ch; l++; }
}
}
    for (i = 0; i < count; i++)
       {
   insertNode(root, ks[i],ks1[i]);
}
cout<<"Enter text to be searched";
    string str;
    cin>>str;
    cout << Meaning(root, str);

    return 0;
}


