#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
using namespace std;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    struct Node {
            bool isEnd;
            map<char,struct Node*> map;
            string meaning;
        };
public:
    Node* root = nullptr;
    void load();
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    Node* getNewTrieNode()
    {
        Node* node = new Node;
        node->isEnd = false;
        return node;
    }
    /**
    * Inserts node
    */
    void insertNode(Node*& root, const string& str,
                const string& meaning)
    {
        if (root == nullptr)
            root = getNewTrieNode();

        Node *temp = root;
        for (int i = 0; i < str.length(); i++) {
            char x = str[i];
            if (temp->map.find(x) == temp->map.end())
                temp->map[x] = getNewTrieNode();

            temp = temp->map[x];
        }
        temp->isEnd= true;
        temp->meaning = meaning;
    }
    /**
    * Takes word and prints meaning
    */
    string Meaning(Node* root,const string& word)
    {
        if (root == nullptr)
            return "Invaid word";

        Node* temp = root;
        for (int i = 0; i < word.length(); i++) {
            temp = temp->map[word[i]];
            if (temp == nullptr)
                return "Invalid word";
        }
        if (temp->isEnd)
            return temp->meaning;
        return "Invalid word";
    }
private slots:
    void on_pushButton_clicked();
private:
    //void on_pushButton_clicked();
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
