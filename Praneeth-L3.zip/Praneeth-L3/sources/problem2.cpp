/*
* @file problem2.cpp
* @brief this file finds the triplets that follow given property.
*
* @author Kurapati Praneeth
*
* @date 20/08/2019
*/
#include <iostream>
using namespace std;
int n;
int c=0;
struct node 
{ 
    int data; 
    node* next;
}; 
node * head=NULL;
/**
* This method will be used to insert a node in linked list.
* @author K.Praneeth
* @param 
* @date 20/08/2019
*/
void insert(int k){
	node *pt = new node();
	pt->data=k;
	if(head==NULL){
		head=pt;
		return;
	}
	node* current=head;
	while(current->next!=NULL){
		current=current->next;
	}
	current->next=pt;
}
/**
* This method will be used to fill linked list.
* @author K.Praneeth
* @param 
* @date 20/08/2019
*/
void p(int a[]){
	int g,k;
	for(int i=1;i<=n;i++)
	for(int j=i;j<=n;j++){
		k=i+1;
		g=a[i-1];
		while(k<=j){
			g=g^a[k-1];
			k++;
		}
		insert(g);
	}
	
}
/**
* This method will return the xor of elements from a[x]to a[y] .
* @author K.Praneeth
* @param 
* @date 20/08/2019
*/
int ask(int x, int y){
	int h=(x-1)*n+y-(x*(x-1))/2;
	node* current=head;
	while(h-->1){
	current=current->next;	
	}
	return current->data;
}
/**
* This method will be used to find no of tripletsand triplets that follow given property.
* @author K.Praneeth
* @param 
* @date 20/08/2019
*/
void m(){
	for(int i=1;i<=n-1;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j;k<=n;k++){
				if(ask(i,j-1)==ask(j,k)){
				c++;	
				}
			}
		}
	}
	printf("%d\n",c);
	for(int i=1;i<=n-1;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j;k<=n;k++){
				if(ask(i,j-1)==ask(j,k)){
				printf("(%d,%d,%d)\n",i,j,k);	
				}
			}
		}
	}
}

int main() {
	cout<<"enter number of elements in sequence"<<endl;
	cin>>n;
	int a[n];
	cout<<"enter all elements in sequence"<<endl;
	for(int i=0;i<n;i++){
		cin>>a[i];
		//cout<<a[i];
	}
	p(a);
	m();
	return 0;
}
 

