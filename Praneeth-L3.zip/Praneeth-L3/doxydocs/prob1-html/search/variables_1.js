var searchData=
[
  ['bhead',['bhead',['../problem1_8cpp.html#af8552e0437246b706504e9c4ae8085ec',1,'problem1.cpp']]]
];
