var searchData=
[
  ['color',['color',['../struct_node.html#ab4722f06caea56c23245657a13b616b3',1,'Node::color()'],['../problem1_8cpp.html#ab87bacfdad76e61b9412d7124be44c1c',1,'Color():&#160;problem1.cpp']]],
  ['count',['count',['../problem1_8cpp.html#ad43c3812e6d13e0518d9f8b8f463ffcf',1,'problem1.cpp']]]
];
