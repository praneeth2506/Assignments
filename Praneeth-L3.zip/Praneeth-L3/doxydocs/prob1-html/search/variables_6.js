var searchData=
[
  ['right',['right',['../struct_node.html#afe5916d969cd32f7de1e4ba15580c989',1,'Node']]]
];
