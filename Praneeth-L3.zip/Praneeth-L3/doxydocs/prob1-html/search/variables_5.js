var searchData=
[
  ['parent',['parent',['../struct_node.html#acb37d05df604a52126aaed3783e35fb2',1,'Node']]]
];
