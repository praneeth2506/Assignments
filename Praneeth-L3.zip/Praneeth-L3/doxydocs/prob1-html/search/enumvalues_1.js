var searchData=
[
  ['red',['RED',['../problem1_8cpp.html#ab87bacfdad76e61b9412d7124be44c1caf80f9a890089d211842d59625e561f88',1,'problem1.cpp']]]
];
