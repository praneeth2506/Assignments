var indexSectionsWithContent =
{
  0: "abcdfghilmnprs",
  1: "nr",
  2: "p",
  3: "bfghilmnprs",
  4: "abcdlpr",
  5: "c",
  6: "br"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

