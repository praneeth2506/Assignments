var searchData=
[
  ['newnode',['newNode',['../problem1_8cpp.html#a770da11603a821bfd0fa82ac18ab9be6',1,'problem1.cpp']]],
  ['node',['Node',['../struct_node.html#a0d68253f48f4deb1e078ef6cf08a5bf4',1,'Node']]]
];
