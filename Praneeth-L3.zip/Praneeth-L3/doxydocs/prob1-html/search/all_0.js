var searchData=
[
  ['ahead',['ahead',['../problem1_8cpp.html#a9590c86286a89969eae43404a657f29e',1,'problem1.cpp']]]
];
