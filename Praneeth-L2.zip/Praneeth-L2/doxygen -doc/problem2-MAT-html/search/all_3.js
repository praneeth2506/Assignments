var searchData=
[
  ['quadrant',['quadrant',['../_m_a_t_8c.html#ae35d27f7d1986dbe53d3239f6cd6191a',1,'MAT.c']]]
];
