/**
* @file inverseTranspose.c
* @brief this file is to decrypte.
*
* @author Kurapati Praneeth
*
* @date 7/08/2019
*/
#include <stdio.h>
/**
* This method will be used to encrypt a data file to other.
* @author K.Praneeth
* @param 
* @date 07/08/2019
*/
int main(int argc, char* argv[]){
	if(argc<5){
	printf("got only %d arguments",argc);
 	return 0;
	}
	FILE* fp=fopen(argv[4],"r");
	if (fp==NULL) 
    { 	
        printf(" input file is not loaded"); 
        return 0;
    } 
	FILE* fo=fopen("fout.txt","w");
	int n,a,b;
	n=atoi(argv[1]);
	a=(atoi(argv[2]))%n;
	b=(atoi(argv[3]))%n;
	if(n<1){
	printf("n is %d",n); 
        return 0;	
	}
	while(a<0||b<0){
		a+=n;
		b+=n;
	}
	int a1,b1;
	int h;
	for(h=0;h<n;h++){
		if((h*n)%a==1)
		{
			a1=(h*n+1)/a;
			b1=n-((a1*b)%n);
		}
	}
	char* d[1000];
	char* d_swap[1000];
	int c=0;//count
	char z;
	while(EOF!=fscanf(fp,"%c",&z)){ 
         d[c]=z;
		  c++;
    } 
    int k,p,f;
    p=c;
    c=0;
    for(k=p;k<p+n-p%n;k++){
            d[k]='\0';
   }
    
    int i[p+n-p%n],j[p+n-p%n]; 
    for(k=0;k<p+n-p%n;k++){
         i[k]=k%n;
        j[k]=(a1*i[k]+b1)%n;
    }
    f=-1;
for(k=0;k<p+n-p%n;k++){
    if(k%n==0) f++; 
    d_swap[i[k]+f*n]=d[j[k]+f*n];
    fputc(d_swap[k],fo);
}
printf("Decryption completed");
	return 0;
}
