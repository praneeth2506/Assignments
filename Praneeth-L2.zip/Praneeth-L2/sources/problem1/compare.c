/**
* @file compare.c
* @brief this file is to compare.
*
* @author Kurapati Praneeth
*
* @date 7/08/2019
*/
#include <stdio.h>
/**
* This method will be used to compare original data file and decrypted data file.
* @author K.Praneeth
* @param 
* @date 07/08/2019
*/

int main(){
    char c1,c2;
    int p=0;

    FILE *fp=fopen("Sample_testcase_1.txt","r");
    FILE *fp2=fopen("fout.txt","r");

    
    while((c1=fgetc(fp))!=EOF&&(c2=fgetc(fp2))!=EOF){
        if(c1!=c2&&(c1!=' '||c2!='\0'))
        printf("No they are different");
        p=1;
        break;
    }
    if(p==0)
    printf("Both files are same");
    return 0;
}
