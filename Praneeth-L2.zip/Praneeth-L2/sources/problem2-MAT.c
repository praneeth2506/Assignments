/**
* @file MAT.c
* @brief this file is Quadrant tree.
*
* @author Kurapati Praneeth
*
* @date 7/08/2019
*/
#include <stdio.h>
#include<math.h>
void quadrant();
int  isEqual();
void print();
int c=1;
int main()
{FILE* fp=fopen("L2_P2_inputsample.txt","r");
   if (fp==NULL) 
    { 	
        printf(" input file is not loaded"); 
        return 0;
    } 
    int size;
    int r=0;
    int count=0;
  while(EOF!=fscanf(fp,"%d ",&r)){
        count++;
    } 
    size=(int)sqrt(count);
    int k=1;
    while(k<size){k=k*2;
	}
	int a[k][k];
	int b[k][k];
	int i,j;
	for(i=0;i<k;i++){
     for(j=0;j<k;j++){
       a[i][j]=0; 
     }
     }
     int d=k-size;
     FILE *fp2=fopen("L2_P2_inputsample.txt","r");
      i=d;
    j=d;
    while(EOF!=fscanf(fp2,"%d ",&r)){
    a[i][j]=r;
    j++;
    if(j>=k){
    	j=d;
    	i++;
	}
    } 
    int n=k;
    quadrant(n,a,0,n-1,0,n-1,b);
    print(n,b);
   return 0;
}
/**
* This method will be used to classify pixel array to Quadrant tree.
* @author K.Praneeth
* @param 
* @date 07/08/2019
*/
void quadrant(int n,int a[n][n],int x1,int x2,int y1,int y2, int b[n][n]){
 
if( x2==x1){
		b[y1][x1]=c;
		int i,j;
     j=y2-y1+1;
	i=1;
    	while(j<n){
		i++;
		j=j*2;
	  }
	printf("(%d,%d,%d,%d,%d,%d,%d)\n",c,a[y1][x1],i,x1,x2,y1,y2);		
  c++;
  return;
}	

if(isEqual(n,a,x1,x2,y1,y2)==1)
{int i,j;
for( i=x1;i<=x2;i++){
		for( j=y1;j<=y2;j++){
			
			b[j][i]=c;
		}
	}
	j=y2-y1+1;
	i=1;
	while(j<n){
		i++;
		j=j*2;
	}
		printf("(%d,%d,%d,%d,%d,%d,%d)\n",c,a[y1][x1],i,x1,x2,y1,y2);	
	c++;
	return;	
}

if(isEqual(n,a,x1,x2,y1,y2)==0&&x1!=x2){
	
quadrant(n,a,x1,(x2+x1-1)/2,y1,(y2+y1-1)/2,b);

quadrant(n,a,(x2+x1+1)/2,x2,y1,(y2+y1-1)/2,b);

quadrant(n,a,x1,(x2+x1-1)/2,(y2+y1+1)/2,y2,b);
	
quadrant(n,a,(x2+x1+1)/2,x2,(y2+y1+1)/2,y2,b);
return;
}
}
/**
* This method will be used to find whether all values are same.
* @author K.Praneeth
* @param 
* @date 07/08/2019
*/
int isEqual(int n,int a[n][n],int x1,int x2,int y1,int y2){
	int i,j;
	for( i=x1;i<=x2;i++){
		for( j=y1;j<=y2;j++){
			if(a[y1][x1]!=a[j][i]){
				return 0;
			
			}
		}
	}
	return 1;
}
/**
* This method will be used to print maximalarray.
* @author K.Praneeth
* @param 
* @date 07/08/2019
*/
void print(int n, int b[n][n]){
	int i,j ;
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
}
